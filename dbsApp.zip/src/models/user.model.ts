export interface User {
    id: Number;
    name: String;
    email: String;
    phone: Number;
    website?: String;
}