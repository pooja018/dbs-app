import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
user:any=[];
url = 'https://jsonplaceholder.typicode.com/posts';

  constructor(private http: HttpClient) { }
  // to get user details
  getUserDetails(){
    return this.http.get(this.url);
  }

  //setting the user details
  setUserDetails(user:any){
    this.user.push(user);
    
    //The Api does not contain the required fields
    this.http.post(this.url,{body:JSON.stringify(this.user),
    headers: {
      'Content-type': 'application/json; charset=UTF-8',
    }});    
  }
  updateUserDetails(user:any){
    this.user.push(user)
        //The Api does not contain the required fields
    this.http.put(this.url,{body:JSON.stringify(this.user),
    headers: {
      'Content-type': 'application/json; charset=UTF-8',
    }}); 
  }
}
