import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UserService } from '../service/user.service';
import { FormGroup, Validators, FormControl, FormBuilder, FormArray } from '@angular/forms';
// import {userData} from '../../models/user.json';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  @ViewChild('editBtn') edit: any;
  userList: any;
  userNames: Array<any> = [];
  userForm: any;
  userListArray: any;
  myNewArray: any;
  btnName = 'Edit';
  // editBtn=true;
  mockData = [
    {
      "id": 1,
      "name": "Ravi",
      "email": "ravi@gmail.com",
      "phone": "5544112234",
      "website": "sdfsfdgdfg"
    },
    {
      "id": 2,
      "name": "Divya",
      "email": "divya@gmail.com",
      "phone": "8877223344",
      "website": "sdfsfdgdfg"
    },
    {
      "id": 1,
      "name": "Sourav",
      "email": "sourav@gmail.com",
      "phone": "7799886543",
      "website": "sdfsfdgdfg"
    }
  ];
 
  constructor(private fb: FormBuilder, private userService: UserService) {
    this.userListArray = this.fb.array([]);
    this.userForm = this.fb.group({});
  }

  ngOnInit(): void {
    for (let i = 0; i < this.mockData.length; i++) {
      this.userListArray.push(this.fb.group({
        name: [{ value: this.mockData[i].name, disabled: true }, [Validators.required]],
        email: [{ value: this.mockData[i].email, disabled: true }, [ Validators.required]],
        phone: [{ value: this.mockData[i].phone, disabled: true }, [ Validators.required]],
        website: [{ value: this.mockData[i].website, disabled: true }]
      }));
    }
    this.userForm.addControl('itemRows', this.userListArray);
  }


  EditUser(index: any): any {
    this.userForm.get('itemRows').controls[index].enable();
  }

  updateUser(index: any) {

    this.userForm.get('itemRows').controls[index].disable();

    //with API call
    // this.mockData.splice(index,1);
    // this.mockData.splice(0,0,this.userForm.controls.itemRows.value[0])
    // this.mockData[index].id=index+1;
    // this.userService.updateUserDetails(this.mockData);
  }

}
