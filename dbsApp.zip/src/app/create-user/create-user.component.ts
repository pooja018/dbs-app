import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, Form } from '@angular/forms';
import { User } from 'src/models/user.model';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  loginForm: any;
  user :any =[];
  id: number = 0;
  //  Array<User> =[] ;
  constructor(private userService:UserService) { }

  ngOnInit(): void {
    this.createLoginForm();
  }

  createLoginForm(){
    this.loginForm = new FormGroup({
      name :new FormControl('', [Validators.required]),
      email:  new FormControl('', [Validators.required]),
      phone: new FormControl('', [Validators.required]),
      website: new FormControl('')
    })
  }
  saveData(){
    this.id= this.id +1;
      this.user={
                id: this.id,
                name : this.loginForm.get('name').value,
                email : this.loginForm.get('email').value,
                phone : this.loginForm.get('phone').value,
                website: this.loginForm.get('website').value
      }
    this.userService.setUserDetails(this.user);

    console.log(this.user);
  }

}
